#! /bin/bash
nitrogen --random --set-scaled & 
picom &
urxvtd -q -o -f &
