run nitrogen --random --set-scaled
